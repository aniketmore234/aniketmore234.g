
Create Database m;

CREATE TABLE IF NOT EXISTS m.facts_stocks AS SELECT 
Company_ID,
Prev_Close,
Open_Price,
High_Price,
Low_Price,
Last_Price,
Close_Price,
Average_Price,
Total_Traded_Quantity,
Turnover,
No_of_Trades,
Deliverable_Qty,
Dly_Qt_to_Traded_Qty
from stockdbmaster.master;

describe m.facts_stocks;

select * from m.facts_stocks;
