Create Database stockdbmaster;
CREATE EXTERNAL TABLE IF NOT EXISTS stockdbmaster.master(
Company_ID string,
Symbol string,
Equity_Series string,
Date_of_record string,
Prev_Close string,
Open_Price string,
High_Price string,
Low_Price string,
Last_Price string,
Close_Price string,
Average_Price string,
Total_Traded_Quantity string,
Turnover string,
No_of_Trades string,
Deliverable_Qty string,
Dly_Qt_to_Traded_Qty string)

ROW FORMAT DELIMITED FIELDS TERMINATED BY ',';

describe stockdbmaster.master;

load data local inpath '/home/hadoop/raw-data' into table stockdbmaster.master;

select * from stockdbmaster.master;
